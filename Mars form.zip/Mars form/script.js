document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('stage1').style.display = 'block';
    document.getElementById('applicationForm').addEventListener('submit', function(event) {
        event.preventDefault();
        document.getElementById('applicationForm').style.display = 'none';
        document.getElementById('successMessage').style.display = 'block';
    });
});

function nextStage(stage) {
    document.querySelectorAll('.form-stage').forEach(stage => stage.style.display = 'none');
    document.getElementById('stage' + stage).style.display = 'block';
}

function previousStage(stage) {
    document.querySelectorAll('.form-stage').forEach(stage => stage.style.display = 'none');
    document.getElementById('stage' + stage).style.display = 'block';
}
